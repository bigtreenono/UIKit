# Camera-Roll
Custom collection view layout that implements "Sticky Headers", as seen in UITableView
